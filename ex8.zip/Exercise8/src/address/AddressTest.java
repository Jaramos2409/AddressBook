package address;

import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class AddressTest {

	@Test
	public void insertAddTest() {
		AddressBook aBook = new AddressBook();
		boolean test = aBook.insertAddress(new AddressEntry("Booda", "Zesty", "555 Gehringer St", "Concord", 
				"CA", "94509", "4155044788", "bluesmith@gmail.com"));
		//for ()
		assertEquals(true, test);
	}

}
